package com.hijoozati.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Calendar

private object C {
    val bg = Color.rgb((6), 4, 12)
    val glass = Color.argb(220, 22, 13, 35)
    val glass2 = Color.argb(235, 15, 12, 24)
    val purple = Color.rgb(181, 54, 255)
    val purple2 = Color.rgb(105, 20, 190)
    val gold = Color.rgb(255, 190, 55)
    val white = Color.rgb(248, 244, 255)
    val muted = Color.rgb(185, 174, 202)
    val green = Color.rgb(48, 220, 112)
    val red = Color.rgb(245, 76, 92)
}

data class Booking(val id: Long, val day: Int, val slot: Int, val team1: String, val team2: String, val phone: String)
data class Tournament(val id: Long, val name: String, val start: String, val end: String)

class LocalDb(context: android.content.Context) : SQLiteOpenHelper(context, "hijoozati.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            day INTEGER NOT NULL, slot INTEGER NOT NULL,
            team1 TEXT NOT NULL, team2 TEXT NOT NULL, phone TEXT NOT NULL,
            UNIQUE(day, slot))""")
        db.execSQL("""CREATE TABLE tournaments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, start_date TEXT NOT NULL DEFAULT '',
            end_date TEXT NOT NULL DEFAULT '')""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun bookings(day: Int): List<Booking> {
        val out = mutableListOf<Booking>()
        readableDatabase.rawQuery("SELECT id,day,slot,team1,team2,phone FROM bookings WHERE day=? ORDER BY slot", arrayOf(day.toString())).use { c ->
            while (c.moveToNext()) out.add(Booking(c.getLong(0), c.getInt(1), c.getInt(2), c.getString(3), c.getString(4), c.getString(5)))
        }
        return out
    }
    fun allBookings(): List<Booking> {
        val out = mutableListOf<Booking>()
        readableDatabase.rawQuery("SELECT id,day,slot,team1,team2,phone FROM bookings ORDER BY day,slot", null).use { c ->
            while (c.moveToNext()) out.add(Booking(c.getLong(0), c.getInt(1), c.getInt(2), c.getString(3), c.getString(4), c.getString(5)))
        }
        return out
    }
    fun booking(day: Int, slot: Int): Booking? {
        readableDatabase.rawQuery("SELECT id,day,slot,team1,team2,phone FROM bookings WHERE day=? AND slot=?", arrayOf(day.toString(), slot.toString())).use { c ->
            if (c.moveToFirst()) return Booking(c.getLong(0), c.getInt(1), c.getInt(2), c.getString(3), c.getString(4), c.getString(5))
        }
        return null
    }
    fun saveBooking(day: Int, slot: Int, team1: String, team2: String, phone: String, id: Long? = null): Boolean {
        val v = ContentValues().apply {
            put("day", day); put("slot", slot); put("team1", team1); put("team2", team2); put("phone", phone)
        }
        return try {
            if (id == null) writableDatabase.insertOrThrow("bookings", null, v)
            else writableDatabase.update("bookings", v, "id=?", arrayOf(id.toString())).toLong()
            true
        } catch (_: Exception) { false }
    }
    fun deleteBooking(id: Long) { writableDatabase.delete("bookings", "id=?", arrayOf(id.toString())) }
    fun tournaments(): List<Tournament> {
        val out = mutableListOf<Tournament>()
        readableDatabase.rawQuery("SELECT id,name,start_date,end_date FROM tournaments ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(Tournament(c.getLong(0), c.getString(1), c.getString(2), c.getString(3)))
        }
        return out
    }
    fun addTournament(name: String) {
        writableDatabase.insert("tournaments", null, ContentValues().apply { put("name", name) })
    }
    fun deleteTournament(id: Long) { writableDatabase.delete("tournaments", "id=?", arrayOf(id.toString())) }
}

class MainActivity : Activity() {
    private lateinit var db: LocalDb
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var selectedDay = Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1
    private var page = "home"
    private val days = listOf("الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LocalDb(this)
        window.statusBarColor = C.bg
        window.navigationBarColor = C.bg
        showApp()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun glassDrawable(radius: Int = 20, gold: Boolean = false): GradientDrawable =
        GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(39, 24, 58), Color.rgb(13, 10, 22), Color.rgb(28, 15, 42))
        ).apply {
            cornerRadius = dp(radius).toFloat()
            setStroke(dp(1), if (gold) C.gold else C.purple)
        }
    private fun text(value: String, size: Float = 16f, color: Int = C.white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(5), dp(6), dp(5), dp(6))
        }
    private fun actionButton(label: String, gold: Boolean = false, action: () -> Unit): TextView =
        text(label, 14f, C.white, true).apply {
            background = glassDrawable(15, gold)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { action() }
        }
    private fun card(title: String, subtitle: String, symbol: String, gold: Boolean = false, action: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = glassDrawable(22, gold)
            setPadding(dp(10), dp(12), dp(10), dp(12))
            addView(text(symbol, 31f, if (gold) C.gold else C.purple, true))
            addView(text(title, 18f, C.white, true))
            addView(text(subtitle, 11f, C.muted))
            setOnClickListener { action() }
        }
    }

    private fun showApp() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(C.bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(14), dp(8), dp(14), dp(8))
        }
        val scroll = ScrollView(this).apply { isFillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        when (page) {
            "home" -> renderHome()
            "bookings" -> renderBookings()
            "tournaments" -> renderTournaments()
            "teams" -> renderTeams()
            else -> renderStats()
        }
        root.addView(bottomNav(), LinearLayout.LayoutParams(-1, dp(66)))
        setContentView(root)
    }

    private fun renderHome() {
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            background = glassDrawable(26)
            setPadding(dp(12), dp(14), dp(12), dp(14))
        }
        val logo = ImageView(this).apply {
            setImageResource(com.hijoozati.app.R.drawable.hijoozati_logo)
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        hero.addView(logo, LinearLayout.LayoutParams(dp(106), dp(106)))
        hero.addView(text("حجوزاتي", 29f, C.white, true))
        hero.addView(text("إدارة الملعب بكل سهولة", 13f, C.muted))
        content.addView(hero, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row1.addView(card("الحجوزات", "إدارة المواعيد والفرق", "▦") { page = "bookings"; showApp() },
            LinearLayout.LayoutParams(0, dp(142), 1f))
        row1.addView(Space(this), LinearLayout.LayoutParams(dp(9), 1))
        row1.addView(card("البطولات", "الفرق والنتائج والترتيب", "🏆", true) { page = "tournaments"; showApp() },
            LinearLayout.LayoutParams(0, dp(142), 1f))
        content.addView(row1)
        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row2.addView(card("الفرق", "أسماء الفرق المسجلة", "♟") { page = "teams"; showApp() },
            LinearLayout.LayoutParams(0, dp(142), 1f))
        row2.addView(Space(this), LinearLayout.LayoutParams(dp(9), 1))
        row2.addView(card("الإحصائيات", "ملخص الحجوزات", "▥") { page = "stats"; showApp() },
            LinearLayout.LayoutParams(0, dp(142), 1f))
        content.addView(row2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })

        content.addView(text("أحدث الحجوزات", 18f, C.white, true).apply { gravity = Gravity.RIGHT; setPadding(0, dp(18), 0, dp(6)) })
        val latest = db.allBookings().takeLast(3).reversed()
        if (latest.isEmpty()) {
            content.addView(text("لا توجد حجوزات بعد — ابدأ بإضافة أول موعد", 13f, C.muted))
        } else latest.forEach { b ->
            val item = text("${days[b.day]}  •  ${slotLabel(b.slot)}\n${b.team1}  ×  ${b.team2}", 14f, C.white, true)
            item.background = glassDrawable(16)
            content.addView(item, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        }
    }

    private fun bottomNav(): LinearLayout {
        val nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = glassDrawable(22)
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(5), dp(4), dp(5))
        }
        val items = listOf(
            Triple("الحجوزات", "▦", "bookings"),
            Triple("الفرق", "♟", "teams"),
            Triple("الرئيسية", "⌂", "home"),
            Triple("البطولات", "🏆", "tournaments"),
            Triple("الإحصائيات", "▥", "stats")
        )
        items.forEach { (label, icon, target) ->
            val active = page == target
            val v = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                background = if (active) glassDrawable(16, target == "tournaments") else null
                addView(text(icon, 20f, if (active) C.gold else C.muted, true))
                addView(text(label, 10f, if (active) C.white else C.muted, active))
                setOnClickListener { page = target; showApp() }
            }
            nav.addView(v, LinearLayout.LayoutParams(0, -1, 1f))
        }
        return nav
    }

    private fun slotLabel(slot: Int): String {
        val h = 18 + slot
        val start = if (h == 12) "12:00 م" else "${h - 12}:00 م"
        val next = (h + 1) % 24
        val end = when {
            next == 0 -> "12:00 ص"
            next < 12 -> "$next:00 ص"
            next == 12 -> "12:00 م"
            else -> "${next - 12}:00 م"
        }
        return "$start – $end"
    }

    private fun renderBookings() {
        content.addView(text("الحجوزات", 23f, C.white, true))
        content.addView(text("اختر اليوم ثم اضغط على الساعة المطلوبة", 12f, C.muted))
        val dayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        days.forEachIndexed { index, day ->
            val b = text(day.take(3), 11f, if (index == selectedDay) C.bg else C.white, true)
            b.background = if (index == selectedDay) GradientDrawable().apply { setColor(C.gold); cornerRadius = dp(12).toFloat() } else glassDrawable(12)
            b.setPadding(dp(2), dp(12), dp(2), dp(12))
            b.setOnClickListener { selectedDay = index; showApp() }
            dayRow.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(3) })
        }
        content.addView(dayRow)
        content.addView(text(days[selectedDay], 18f, C.gold, true))
        for (slot in 0..5) {
            val existing = db.booking(selectedDay, slot)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = glassDrawable(17, existing != null)
                setPadding(dp(12), dp(9), dp(12), dp(9))
            }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
            details.addView(text(slotLabel(slot), 16f, C.white, true).apply { gravity = Gravity.RIGHT })
            details.addView(text(if (existing == null) "اضغط للحجز" else "${existing.team1} × ${existing.team2}", 12f, C.muted).apply { gravity = Gravity.RIGHT })
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text(if (existing == null) "متاح" else "محجوزة", 13f, if (existing == null) C.green else C.gold, true))
            row.setOnClickListener { if (existing == null) bookingDialog(slot, null) else bookingDetails(existing) }
            content.addView(row, LinearLayout.LayoutParams(-1, dp(70)).apply { topMargin = dp(8) })
        }
    }

    private fun bookingDialog(slot: Int, current: Booking?) {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        fun field(hint: String, value: String = ""): EditText {
            val e = EditText(this).apply {
                this.hint = hint; setText(value); textSize = 15f; setTextColor(C.white); setHintTextColor(C.muted)
                background = glassDrawable(12); setPadding(dp(12), dp(9), dp(12), dp(9))
            }
            form.addView(e, LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(8) })
            return e
        }
        val a = field("اسم الفريق الأول", current?.team1 ?: "")
        val b = field("اسم الفريق الثاني", current?.team2 ?: "")
        val p = field("رقم الهاتف", current?.phone ?: "")
        val dialog = AlertDialog.Builder(this).setTitle(if (current == null) "حجز موعد – ساعة واحدة" else "تعديل الحجز")
            .setView(form).setPositiveButton(if (current == null) "تأكيد الحجز" else "حفظ التعديل", null)
            .setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val t1 = a.text.toString().trim(); val t2 = b.text.toString().trim(); val phone = p.text.toString().trim()
                if (t1.isEmpty() || t2.isEmpty() || phone.isEmpty()) Toast.makeText(this, "يرجى ملء جميع الحقول", Toast.LENGTH_SHORT).show()
                else if (db.saveBooking(selectedDay, slot, t1, t2, phone, current?.id)) { dialog.dismiss(); showApp() }
                else Toast.makeText(this, "هذا الموعد محجوز بالفعل", Toast.LENGTH_LONG).show()
            }
        }
        dialog.show()
    }

    private fun bookingDetails(b: Booking) {
        AlertDialog.Builder(this).setTitle("تفاصيل الحجز")
            .setMessage("${days[b.day]} – ${slotLabel(b.slot)}\n\nالفريق الأول: ${b.team1}\nالفريق الثاني: ${b.team2}\nرقم الهاتف: ${b.phone}\n\nمدة الحجز: ساعة واحدة")
            .setPositiveButton("تعديل") { _, _ -> bookingDialog(b.slot, b) }
            .setNegativeButton("إغلاق", null)
            .setNeutralButton("إلغاء الحجز") { _, _ ->
                AlertDialog.Builder(this).setMessage("هل تريد إلغاء هذا الحجز؟")
                    .setPositiveButton("نعم، إلغاء") { _, _ -> db.deleteBooking(b.id); showApp() }
                    .setNegativeButton("رجوع", null).show()
            }.show()
    }

    private fun renderTournaments() {
        content.addView(text("البطولات", 23f, C.white, true))
        content.addView(text("أنشئ بطولاتك واحتفظ بها على جهازك", 12f, C.muted))
        content.addView(actionButton("+ إنشاء بطولة", true) { tournamentDialog() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(10) })
        val list = db.tournaments()
        if (list.isEmpty()) content.addView(text("لا توجد بطولات حالياً", 15f, C.muted))
        list.forEach { t ->
            val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = glassDrawable(18, true); setPadding(dp(12), dp(8), dp(12), dp(8)) }
            box.addView(text("🏆  ${t.name}", 17f, C.gold, true))
            box.addView(text("بطولة محفوظة على هذا الجهاز", 12f, C.muted))
            box.addView(actionButton("حذف البطولة") {
                AlertDialog.Builder(this).setMessage("حذف البطولة؟")
                    .setPositiveButton("حذف") { _, _ -> db.deleteTournament(t.id); showApp() }
                    .setNegativeButton("إلغاء", null).show()
            })
            content.addView(box, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
    }
    private fun tournamentDialog() {
        val input = EditText(this).apply { hint = "اسم البطولة"; setTextColor(C.white); setHintTextColor(C.muted); background = glassDrawable(12); setPadding(dp(12), dp(10), dp(12), dp(10)) }
        AlertDialog.Builder(this).setTitle("بطولة جديدة").setView(input)
            .setPositiveButton("إنشاء") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) { db.addTournament(name); showApp() } else Toast.makeText(this, "اكتب اسم البطولة", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("إلغاء", null).show()
    }

    private fun renderTeams() {
        content.addView(text("الفرق المسجلة", 23f, C.white, true))
        val teams = db.allBookings().flatMap { listOf(it.team1, it.team2) }.distinct()
        if (teams.isEmpty()) content.addView(text("ستظهر هنا أسماء الفرق بعد تسجيل الحجوزات", 13f, C.muted))
        teams.forEach { name ->
            val item = text("♟   $name", 17f, C.white, true)
            item.background = glassDrawable(16)
            content.addView(item, LinearLayout.LayoutParams(-1, dp(58)).apply { topMargin = dp(8) })
        }
    }
    private fun renderStats() {
        val all = db.allBookings()
        content.addView(text("الإحصائيات", 23f, C.white, true))
        content.addView(text("ملخص نشاط الملعب", 12f, C.muted))
        val booked = all.size
        val card1 = text("إجمالي الحجوزات\n$booked", 22f, C.white, true)
        card1.background = glassDrawable(20)
        content.addView(card1, LinearLayout.LayoutParams(-1, dp(105)).apply { topMargin = dp(14) })
        val card2 = text("عدد البطولات\n${db.tournaments().size}", 20f, C.gold, true)
        card2.background = glassDrawable(20, true)
        content.addView(card2, LinearLayout.LayoutParams(-1, dp(105)).apply { topMargin = dp(10) })
    }
}
