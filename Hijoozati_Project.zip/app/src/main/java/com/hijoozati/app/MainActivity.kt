package com.hijoozati.app

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.content.ContentValues
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.view.Gravity
import android.view.View
import android.widget.*
import java.util.Calendar

private object Palette {
    val bg = Color.rgb(8, 11, 10)
    val panel = Color.rgb(21, 26, 24)
    val panel2 = Color.rgb(29, 35, 32)
    val green = Color.rgb(57, 232, 121)
    val greenDark = Color.rgb(19, 93, 49)
    val gold = Color.rgb(245, 196, 75)
    val red = Color.rgb(239, 75, 75)
    val white = Color.WHITE
    val muted = Color.rgb(170, 181, 174)
}

data class Booking(val id: Long, val day: Int, val slot: Int, val team1: String, val team2: String, val phone: String)
data class Tournament(val id: Long, val name: String, val start: String, val end: String)

class LocalDb(context: android.content.Context) : SQLiteOpenHelper(context, "hijoozati.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE bookings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            day INTEGER NOT NULL, slot INTEGER NOT NULL,
            team1 TEXT NOT NULL, team2 TEXT NOT NULL, phone TEXT NOT NULL,
            UNIQUE(day, slot))""")
        db.execSQL("""CREATE TABLE tournaments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, start_date TEXT NOT NULL DEFAULT '',
            end_date TEXT NOT NULL DEFAULT '')""")
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun bookings(day: Int): List<Booking> {
        val out = mutableListOf<Booking>()
        readableDatabase.rawQuery("SELECT id,day,slot,team1,team2,phone FROM bookings WHERE day=? ORDER BY slot", arrayOf(day.toString())).use { c ->
            while (c.moveToNext()) out.add(Booking(c.getLong(0), c.getInt(1), c.getInt(2), c.getString(3), c.getString(4), c.getString(5)))
        }
        return out
    }
    fun booking(day: Int, slot: Int): Booking? {
        readableDatabase.rawQuery("SELECT id,day,slot,team1,team2,phone FROM bookings WHERE day=? AND slot=?", arrayOf(day.toString(), slot.toString())).use { c ->
            if (c.moveToFirst()) return Booking(c.getLong(0), c.getInt(1), c.getInt(2), c.getString(3), c.getString(4), c.getString(5))
        }
        return null
    }
    fun saveBooking(day: Int, slot: Int, team1: String, team2: String, phone: String, id: Long? = null): Boolean {
        val v = ContentValues().apply {
            put("day", day); put("slot", slot); put("team1", team1); put("team2", team2); put("phone", phone)
        }
        return try {
            if (id == null) writableDatabase.insertOrThrow("bookings", null, v)
            else writableDatabase.update("bookings", v, "id=?", arrayOf(id.toString())).toLong()
            true
        } catch (_: Exception) { false }
    }
    fun deleteBooking(id: Long) { writableDatabase.delete("bookings", "id=?", arrayOf(id.toString())) }
    fun tournaments(): List<Tournament> {
        val out = mutableListOf<Tournament>()
        readableDatabase.rawQuery("SELECT id,name,start_date,end_date FROM tournaments ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) out.add(Tournament(c.getLong(0), c.getString(1), c.getString(2), c.getString(3)))
        }
        return out
    }
    fun addTournament(name: String) {
        writableDatabase.insert("tournaments", null, ContentValues().apply { put("name", name) })
    }
    fun deleteTournament(id: Long) { writableDatabase.delete("tournaments", "id=?", arrayOf(id.toString())) }
}

class MainActivity : Activity() {
    private lateinit var db: LocalDb
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private var selectedDay = (Calendar.getInstance().get(Calendar.DAY_OF_WEEK) - 1)
    private var tournamentsTab = false
    private val days = listOf("الأحد", "الإثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة", "السبت")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LocalDb(this)
        window.statusBarColor = Palette.bg
        window.navigationBarColor = Palette.bg
        showApp()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun rounded(color: Int, radius: Int = 18, stroke: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(color); cornerRadius = dp(radius).toFloat()
            if (stroke != 0) setStroke(dp(1), stroke)
        }

    private fun text(value: String, size: Float = 16f, color: Int = Palette.white, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(6), dp(7), dp(6), dp(7))
        }

    private fun button(label: String, color: Int, textColor: Int = Palette.white, action: () -> Unit): TextView =
        text(label, 15f, textColor, true).apply {
            background = rounded(color, 14, if (color == Palette.panel) Palette.green else 0)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener { action() }
        }

    private fun showApp() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Palette.bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(dp(16), dp(12), dp(16), dp(10))
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
        header.addView(text("⚽", 34f, Palette.green, true))
        header.addView(text("حجوزاتي", 27f, Palette.white, true))
        header.addView(text("إدارة حجوزات الملعب والبطولات", 12f, Palette.muted))
        root.addView(header)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(14), 0, dp(12)) }
        nav.addView(button("الحجوزات", if (!tournamentsTab) Palette.greenDark else Palette.panel, Palette.white) {
            tournamentsTab = false; showApp()
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        nav.addView(Space(this), LinearLayout.LayoutParams(dp(10), 1))
        nav.addView(button("🏆 البطولات", if (tournamentsTab) Palette.greenDark else Palette.panel, Palette.white) {
            tournamentsTab = true; showApp()
        }, LinearLayout.LayoutParams(0, dp(48), 1f))
        root.addView(nav)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this).apply { isFillViewport = true; addView(content) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        if (tournamentsTab) renderTournaments() else renderBookings()
        setContentView(root)
    }

    private fun renderBookings() {
        content.addView(text("اختر اليوم", 18f, Palette.white, true))
        val dayRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        days.forEachIndexed { index, day ->
            val b = text(day.take(3), 12f, if (index == selectedDay) Palette.bg else Palette.white, true)
            b.background = rounded(if (index == selectedDay) Palette.green else Palette.panel, 12)
            b.setPadding(dp(3), dp(12), dp(3), dp(12))
            b.setOnClickListener { selectedDay = index; showApp() }
            dayRow.addView(b, LinearLayout.LayoutParams(0, dp(48), 1f).apply { marginEnd = dp(3) })
        }
        content.addView(dayRow)
        content.addView(text(days[selectedDay], 19f, Palette.green, true))
        for (slot in 0..5) {
            val start = 18 + slot
            val endHour = (start + 1) % 24
            val end = when {
                endHour == 0 -> "12:00 ص"
                endHour < 12 -> "$endHour:00 ص"
                endHour == 12 -> "12:00 م"
                else -> "${endHour - 12}:00 م"
            }
            val startLabel = if (start == 18) "6:00 م" else if (start < 24) String.format("%d:00 م", start - 12) else "12:00 ص"
            val existing = db.booking(selectedDay, slot)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = rounded(Palette.panel, 16, if (existing == null) Palette.greenDark else Palette.gold)
                setPadding(dp(10), dp(8), dp(10), dp(8))
            }
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL }
            info.addView(text("$startLabel – $end", 16f, Palette.white, true))
            info.addView(text(if (existing == null) "متاح للحجز" else "${existing.team1} × ${existing.team2}", 12f, if (existing == null) Palette.green else Palette.gold))
            row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text(if (existing == null) "متاح" else "محجوزة", 13f, if (existing == null) Palette.green else Palette.gold, true))
            row.setOnClickListener { if (existing == null) bookingDialog(slot, null) else bookingDetails(existing) }
            val lp = LinearLayout.LayoutParams(-1, dp(72)); lp.topMargin = dp(9)
            content.addView(row, lp)
        }
        content.addView(text("اضغط على الوقت المتاح لإضافة حجز، أو المحجوز لعرض التفاصيل.", 11f, Palette.muted))
    }

    private fun bookingDialog(slot: Int, current: Booking?) {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(8), dp(20), 0) }
        fun field(hint: String, value: String = ""): EditText {
            val e = EditText(this).apply {
                this.hint = hint; setText(value); textSize = 15f; setTextColor(Palette.white); setHintTextColor(Palette.muted)
                background = rounded(Palette.panel2, 10); setPadding(dp(12), dp(9), dp(12), dp(9))
            }
            val lp = LinearLayout.LayoutParams(-1, dp(52)); lp.topMargin = dp(8); form.addView(e, lp)
            return e
        }
        val a = field("اسم الفريق الأول", current?.team1 ?: "")
        val b = field("اسم الفريق الثاني", current?.team2 ?: "")
        val p = field("رقم الهاتف", current?.phone ?: "")
        val dialog = AlertDialog.Builder(this).setTitle(if (current == null) "حجز موعد – ساعة واحدة" else "تعديل الحجز")
            .setView(form)
            .setPositiveButton(if (current == null) "تأكيد الحجز" else "حفظ التعديل", null)
            .setNegativeButton("إلغاء", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val team1 = a.text.toString().trim(); val team2 = b.text.toString().trim(); val phone = p.text.toString().trim()
                if (team1.isEmpty() || team2.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(this, "يرجى ملء جميع الحقول", Toast.LENGTH_SHORT).show()
                } else {
                    val ok = db.saveBooking(selectedDay, slot, team1, team2, phone, current?.id)
                    if (ok) { dialog.dismiss(); showApp() }
                    else Toast.makeText(this, "هذا الموعد محجوز بالفعل", Toast.LENGTH_LONG).show()
                }
            }
        }
        dialog.show()
    }

    private fun bookingDetails(b: Booking) {
        AlertDialog.Builder(this).setTitle("تفاصيل الحجز")
            .setMessage("${days[b.day]} – الموعد رقم ${b.slot + 1}\n\nالفريق الأول: ${b.team1}\nالفريق الثاني: ${b.team2}\nرقم الهاتف: ${b.phone}\n\nمدة الحجز: ساعة واحدة")
            .setPositiveButton("تعديل") { _, _ -> bookingDialog(b.slot, b) }
            .setNegativeButton("إغلاق", null)
            .setNeutralButton("إلغاء الحجز") { _, _ ->
                AlertDialog.Builder(this).setMessage("هل تريد إلغاء هذا الحجز؟")
                    .setPositiveButton("نعم، إلغاء") { _, _ -> db.deleteBooking(b.id); showApp() }
                    .setNegativeButton("رجوع", null).show()
            }.show()
    }

    private fun renderTournaments() {
        content.addView(text("البطولات", 21f, Palette.white, true))
        content.addView(text("أنشئ بطولاتك واحتفظ بأسمائها محلياً على الهاتف.", 12f, Palette.muted))
        content.addView(button("+ إنشاء بطولة", Palette.greenDark, Palette.white) { tournamentDialog() },
            LinearLayout.LayoutParams(-1, dp(52)).apply { topMargin = dp(12); bottomMargin = dp(10) })
        val list = db.tournaments()
        if (list.isEmpty()) content.addView(text("لا توجد بطولات حالياً", 15f, Palette.muted))
        list.forEach { t ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = rounded(Palette.panel, 16, Palette.greenDark)
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            card.addView(text("🏆  ${t.name}", 17f, Palette.gold, true))
            card.addView(text("بطولة محفوظة على هذا الجهاز", 12f, Palette.muted))
            card.addView(button("حذف البطولة", Palette.panel2, Palette.red) {
                AlertDialog.Builder(this).setMessage("حذف البطولة؟")
                    .setPositiveButton("حذف") { _, _ -> db.deleteTournament(t.id); showApp() }
                    .setNegativeButton("إلغاء", null).show()
            })
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }
    }

    private fun tournamentDialog() {
        val input = EditText(this).apply {
            hint = "اسم البطولة"; setTextColor(Palette.white); setHintTextColor(Palette.muted)
            background = rounded(Palette.panel2, 10); setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        AlertDialog.Builder(this).setTitle("بطولة جديدة").setView(input)
            .setPositiveButton("إنشاء") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isNotEmpty()) { db.addTournament(name); showApp() }
                else Toast.makeText(this, "اكتب اسم البطولة", Toast.LENGTH_SHORT).show()
            }.setNegativeButton("إلغاء", null).show()
    }
}
